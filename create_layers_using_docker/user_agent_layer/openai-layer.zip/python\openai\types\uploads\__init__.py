# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from .upload_part import UploadPart as UploadPart
from .part_create_params import PartCreateParams as PartCreateParams
